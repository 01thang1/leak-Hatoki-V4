# HaToKi-V4
Install HaToki V4 In Win,Unbutu,Linux

git clone https://github.com/tdd2006/HaToKi-V4/
cd HaToki-V4

python Setup-HaTaKi.py

python HaToKi.py


Install In Termux (Android)

git clone https://github.com/tdd2006/HaToKi-V4.git

cd HaToki-V4

python Setup-HaTaKi.py

python HaToKi.py
